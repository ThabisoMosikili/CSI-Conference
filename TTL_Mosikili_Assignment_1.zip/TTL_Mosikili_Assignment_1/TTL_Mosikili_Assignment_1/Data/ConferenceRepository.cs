﻿using Microsoft.EntityFrameworkCore;
using TTL_Mosikili_Assignment_1.Models;

namespace TTL_Mosikili_Assignment_1.Data
{
    public class ConferenceRepository : IConferenceRepository
    {
        private readonly AppDbContext _appDbContext;


        public ConferenceRepository(AppDbContext dbContext)
        {
            _appDbContext = dbContext;
        }

        public IEnumerable<Attendee> GetAttendeesWithCapacityDetails()
        {
            return _appDbContext.Attendees.Include(a => a.Capacity);

        }


        public IEnumerable<Capacity> GetCapacities()
        {
            return _appDbContext.Capacities;
        }

        public void AddAttendee(Attendee attendee)
        {
            _appDbContext.Attendees.Add(attendee);
        }

        public Attendee GetAttendeeByEmail(string email)
        {
            return _appDbContext.Attendees.FirstOrDefault(a => email.ToLower() == email.ToLower());


        }

        public void SaveChanges()
        {
            _appDbContext.SaveChanges();
        }





  

}
}