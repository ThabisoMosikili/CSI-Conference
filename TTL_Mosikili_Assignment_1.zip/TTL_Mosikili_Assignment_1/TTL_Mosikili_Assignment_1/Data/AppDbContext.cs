﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using TTL_Mosikili_Assignment_1.Models;

namespace TTL_Mosikili_Assignment_1.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {


        }

        public DbSet<Attendee> Attendees { get; set; }
        public DbSet<Capacity> Capacities { get; set; }
    }
}
