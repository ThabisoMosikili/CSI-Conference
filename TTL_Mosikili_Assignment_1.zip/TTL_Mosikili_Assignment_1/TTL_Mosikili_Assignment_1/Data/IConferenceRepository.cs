﻿using TTL_Mosikili_Assignment_1.Models;

namespace TTL_Mosikili_Assignment_1.Data
{
    public interface IConferenceRepository
    {
        IEnumerable<Attendee> GetAttendeesWithCapacityDetails();
        Attendee GetAttendeeByEmail(string email);
        void AddAttendee(Attendee attendee);
        IEnumerable<Capacity> GetCapacities();

        void SaveChanges();


    }
}
