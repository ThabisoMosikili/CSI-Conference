﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TTL_Mosikili_Assignment_1.Data;
using TTL_Mosikili_Assignment_1.Models;
using System.ComponentModel.DataAnnotations;

namespace TTL_Mosikili_Assignment_1.Controllers
{
    public class AttendeeController : Controller
    {
        private readonly IConferenceRepository _conferenceRepository;
        public AttendeeController(IConferenceRepository conferenceRepository)
        {
            _conferenceRepository = conferenceRepository;
        }
        [HttpPost]
        public IActionResult Check(string email)
        {
            if (ModelState.IsValid)
            {
                var attendee = _conferenceRepository.GetAttendeeByEmail(email);
                if (attendee == null)
                {
                    ViewBag.ErrorMessage = "You are already registered for the conference";
                }
                else
                {
                    return RedirectToAction("Register", new { email });
                    
                }
            }
            return View();
        }

        [HttpGet]
        public IActionResult Check()
        {
            return View();
        }

       

        public IActionResult List()
        {
            return View(_conferenceRepository.GetAttendeesWithCapacityDetails().OrderBy(a => a.Name));
        }


        private void PopulateCapacityDDL(object selectCapacity = null)
        {
            ViewBag.Capacities = new SelectList(_conferenceRepository.GetCapacities().OrderBy(c => c.CapacityName)
                , "CapacityId", "CapacityName", selectCapacity);
        }
        [HttpGet]
        public IActionResult Register(string email)
        {
            PopulateCapacityDDL();
            var attendee = new Attendee
            {
                Email = email
            };


            return View(attendee);
        }

        [HttpPost]
        public IActionResult Register([Required] Attendee attendee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _conferenceRepository.AddAttendee(attendee);
                    _conferenceRepository.SaveChanges();

                    PopulateCapacityDDL();
                    return View("Confirmation", attendee);
                }
                catch (DbUpdateException)
                {

                    ModelState.TryAddModelError("", "Unable to save changes." + "Try again, and if the problem presists," +
                        "Contact yourn system admininstrator");
                }
            }
            PopulateCapacityDDL();
            return View(attendee);
        }
    }
}
