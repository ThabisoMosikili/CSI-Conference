﻿using Microsoft.AspNetCore.Mvc;

namespace TTL_Mosikili_Assignment_1.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
