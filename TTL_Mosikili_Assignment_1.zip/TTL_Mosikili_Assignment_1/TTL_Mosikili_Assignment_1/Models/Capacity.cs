﻿namespace TTL_Mosikili_Assignment_1.Models
{
    public class Capacity
    {
        public int CapacityId { get; set; }
        public string CapacityName { get; set; }

        public List<Attendee> Attendees { get; set; }


    }
}
