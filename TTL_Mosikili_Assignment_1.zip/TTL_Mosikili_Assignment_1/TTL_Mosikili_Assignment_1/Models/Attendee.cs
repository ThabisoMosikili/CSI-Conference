﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace TTL_Mosikili_Assignment_1.Models
{
    public class Attendee
    {

        public int AttendeeID { get; set; }

        [Required(ErrorMessage = "Please enter your name)")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 50 charecters")]
        public string Name { get; set; }


        [Required(ErrorMessage = "Please enter your phone number")]
        [DisplayName("Phone Number")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Please enter your email")]
        [RegularExpression(".+\\@.+\\..+", ErrorMessage = "Please enter a valid email adress")]
        public string Email { get; set; }


        [Required(ErrorMessage = "Please select the capacity in which you will be attend")]
        public int CapacityId { get; set; }

        public Capacity Capacity { get; set; }





    }
}
